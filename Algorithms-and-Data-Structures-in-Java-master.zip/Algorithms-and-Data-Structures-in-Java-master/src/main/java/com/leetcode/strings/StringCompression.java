package com.leetcode.strings;

/**
 * @author rampatra
 * @since 2019-04-16
 */
public class StringCompression {
    
    private static int compress(char[] chars) {
        return -1;
    }
    
    public static void main(String[] args) {
    }
}
