package com.hackerrank.projecteuler;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @author rampatra
 * @since 1/1/16
 * @time: 8:48 AM
 */
public class MultiplesOf3and5 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int t = Integer.parseInt(in.nextLine());

    }
}
