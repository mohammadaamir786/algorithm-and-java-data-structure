package com.rampatra.base;

/**
 * A rudimentary Graph having all the basic methods.
 *
 * @author rampatra
 * @since 2019-02-10
 */
public class Graph<E extends Comparable<E>> {
}
