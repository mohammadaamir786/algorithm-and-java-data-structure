package com.rampatra.base;

/**
 * Created by IntelliJ IDEA.
 * User: rampatra
 * Date: 4/19/15
 * Time: 6:30 PM
 * To change this template go to Preferences | IDE Settings | File and Code Templates
 */
public class Tree<E extends Comparable<E>> {

}
