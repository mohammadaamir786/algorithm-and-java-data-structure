package com.rampatra.trees;

import com.rampatra.base.BinaryNode;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 *
 * @author rampatra
 * @since 6/26/15
 * @time: 5:34 PM
 */
public class ConstructTreeFromInOrderAndPreOrder {

    public <E extends Comparable<E>> void constructTreeWithInOrderAndPreOrder(List<BinaryNode<E>> inOrder,
                                                                              List<BinaryNode<E>> preOrder) {
        for (int i = 0; i < preOrder.size(); i++) {

        }
    }

    public static void main(String[] args) {

    }
}
